#include "gige.h"

__attribute__((__aligned__(16), __section__(".region_dma_nocache"))) \
uint32_t rxframelist[NUM_RX_FRAMES << 1];
__attribute__((__aligned__(16), __section__(".region_dma_nocache"))) \
uint32_t txframelist[NUM_TX_FRAMES << 1];

__attribute__((__aligned__(16), __section__(".region_dma_nocache"))) uint8_t rxbuf[RX_BUF_SPACE];
__attribute__((__aligned__(16), __section__(".region_dma_nocache"))) uint8_t txbuf[TX_BUF_SPACE];

uint16_t Read_PHY(uint8_t reg, uint8_t addr)
{
    //wait for pending PHY operation
    while(!(GMAC->GMAC_NSR & (0b1 << 2)));

    //set up register for reading PHY
    GMAC->GMAC_MAN = (0b0 << 31) | (0b1 << 30) | (0b10 << 28) | ((addr & 0x1f) << 23)
                     | ((reg & 0x1f) << 18) | (0b10 << 16);

    //wait for the PHY to talk back
    while(!(GMAC->GMAC_NSR & (0b1 << 2)));

    return GMAC->GMAC_MAN & 0xffff;
}

void Write_PHY(uint8_t reg, uint8_t addr, uint16_t data)
{
    //wait for pending PHY operation
    while(!(GMAC->GMAC_NSR & (0b1 << 2)));

    //set up register for writing PHY
    GMAC->GMAC_MAN = (0b0 << 31) | (0b1 << 30) | (0b01 << 28) | ((addr & 0x1f) << 23)
                     | ((reg & 0x1f) << 18) | (0b10 << 16) | data;

    //wait for transmission to end
    while(!(GMAC->GMAC_NSR & (0b1 << 2)));
}

void PHY_restart_auto_negotiation(int addr)
{
    //write to "restart bit"
    uint16_t read = Read_PHY(0, addr);
    read |= (1 << 9);
    Write_PHY(0, addr, read);
    
    //poll for completion
    while(Read_PHY(0, addr) & (1 << 9));
}

void PHY_auto_negotiate()
{
    int retry_count = 0;

begin:
    retry_count;
    int u = 0;
    while(1)
    {
	int j;
        if((j = Read_PHY(0x01, PHY_ADDR)) & (1 << 5))
        {
	    break;
        }
    }
    printf("Ethernet partner connected.\r\n");
    
    //get info about partner.
    uint16_t gige_partner = Read_PHY(0x0a, PHY_ADDR);
    if(gige_partner & (1 << 11))
    {
        printf("partner is capable of 1000Base-T full-duplex!\r\n");
    }
    if(gige_partner & (1 << 10))
    {
         printf("partner is capable of 1000Base-T half-duplex!\r\n");
    }
    gige_partner = Read_PHY(0x1f, PHY_ADDR);

    if(gige_partner & (1 << 6))
    {
        printf("Speed status 1000Base-T\r\n");
    }
    else if(gige_partner & (1 << 5))
    {
        printf("Speed status 100Base-TX\r\n");
	if(retry_count++ < 4)
	{
	    printf("retrying\r\n");
	    PHY_restart_auto_negotiation(1);
	    goto begin;
	}
    }
    else if(gige_partner & (1 << 4))
    {
        printf("Speed status 10Base-T\r\n");
	if(retry_count++ < 4)
	{
	    printf("retrying...\r\n");
	    PHY_restart_auto_negotiation(1);
	    goto begin;
	}
    }
    if(gige_partner & (1 << 3))
    {
        printf("using Full-duplex.\r\n");
    }
    else
    {
        printf("using Half-duplex.\r\n");
    }
}

void construct_rx_descriptor_list(uint8_t* bufspace, uint32_t* listspace,
					 uint16_t frame_len, uint16_t num_frames)
{
    //initialize each descriptor.
    int i;
    uint32_t addr = (uint32_t)bufspace;
    for(i = 0; i < num_frames; i++)
    {
        listspace[i*2] = addr;
        listspace[i*2 + 1] = frame_len ;
        addr += frame_len;
    }
    
    //set the "wrap" bit of the very last descriptor.
    listspace[(--i)*2] |= (1 << 1);
}

void construct_tx_descriptor_list(uint8_t* bufspace, uint32_t* listspace,
					 uint16_t frame_len, uint16_t num_frames)
{
    int i;
    uint32_t addr = (uint32_t)bufspace;
    for(i = 0; i < num_frames; i++)
    {
        listspace[i*2] = addr;
        listspace[i*2 + 1] = frame_len | (1 << 15) | (1 << 31);
        addr += frame_len;
    }
    listspace[(--i)*2 + 1] |= (1 << 30);
}


void dump_PHY_registers(int addr)
{
    int i;
    int j;
    for(i = 0; i < 32;)
    {
        printf("%i  ", i);
        for(j = 0; j < 4; j++, i++)
        {
            printf("%04x ", Read_PHY(i, addr));
        }
        printf("\r\n");
    }
    
    printf("100  ");
    for(i = 0x100; i < 0x107; i++)
    {
	Write_PHY(0x0b, addr, i);
	printf("%04x ", Read_PHY(0x0d, addr));
    }
    printf("\r\n");
}

