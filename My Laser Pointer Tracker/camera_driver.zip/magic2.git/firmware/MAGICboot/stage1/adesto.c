#include "adesto.h"

//sends the data in buf over the SPI0 bus chip select 0 and writes the MISO
//data back into buf.  Assumes that the
void adesto_xfer(uint8_t* buf, uint32_t len)
{
    //wait until ready and do an initial read.
    while(!(SPI0->SPI_SR & SPI_SR_TXEMPTY));
    int r = SPI0->SPI_RDR;

    uint32_t i;
    for(i = 0; i < len; i++)
    {
        //check for last xfer
        if(i == (len - 1))
        {
            SPI0->SPI_TDR = buf[i] | (1 << 24) | (CHIP_SELECT << 16);
            SPI0->SPI_CR = 0x01000000;
        }
        else
        {
            SPI0->SPI_TDR = buf[i] | (CHIP_SELECT << 16);
        }

        while(!(SPI0->SPI_SR & SPI_SR_RDRF));
        buf[i] = SPI0->SPI_RDR & 0xff;
        //while(!(SPI0->SPI_SR & SPI_SR_TXEMPTY));
    }
}

//returns the adesto status register.
uint32_t adesto_read_status_register(void)
{
    uint8_t buf[] = {0x05, 0, 0};
    adesto_xfer(buf, 3);
    return (uint32_t)buf[1] | ((uint32_t)buf[2] << 8);
}

//waits until the adesto is not busy OR until the timeout is reached.  Returns
//milliseconds spent waiting.
uint32_t adesto_wait_not_busy(uint32_t timeout)
{
    //uint32_t maxtime = timeout + timestamp;
    int busy;
    do
    {
	busy = adesto_read_status_register();
	busy &= 0x01;
    }while(busy);

    if(busy & 0x01)
    {
	return -1;
    }

    return 1;
    //return (timestamp - maxtime + timeout);
}

int32_t adesto_write_enable()
{
    //make sure that adesto is not busy.
    if(adesto_wait_not_busy(1000) < 0)
    {
	return -1;
    }
    uint8_t buf[] = {0x06};
    adesto_xfer(buf, 1);

    if(adesto_read_status_register() & 0x02)
    {
	return 1;
    }
    else
    {
	return -2;
    }
}

//returns status protection register, or, in the case of a timeout or other
//error, returns -1.
int32_t adesto_read_status_protection_register(uint32_t addr)
{
    //make sure that adesto is not busy.
    if(adesto_wait_not_busy(1000) < 0)
    {
	return -1;
    }

    uint8_t buf[] = {0x3c, (addr >> 16) & 0xff, (addr >> 8) & 0xff, addr & 0xff, 0};
    adesto_xfer(buf, 5);
    return ((int32_t)buf[4]) & 0xff;
}

int32_t adesto_unprotect_sector(uint32_t addr)
{
    //make sure that adesto is not busy.
    if(adesto_wait_not_busy(1000) < 0)
    {
	return -1;
    }

    //write enable
    if(adesto_write_enable() < 0)
    {
	return -2;
    }

    //unprotect the sector
    uint8_t buf[] = {0x39, (addr >> 16) & 0xff, (addr >> 8) & 0xff, addr & 0xff};
    adesto_xfer(buf, 4);

    //verify that the sector was indeed unprotected.
    //make sure that adesto is not busy.
    if(adesto_wait_not_busy(1000) < 0)
    {
	return -1;
    }

    if(adesto_read_status_protection_register(addr))
    {
	return -2;
    }

    return 0;
}

//does a full erase of the adesto.  Returns millis spent waiting if successful,
//returns a negative number if there was an error/timeout.
int32_t adesto_full_erase(int timeout)
{
    //write enable
    if(adesto_write_enable() < 0)
    {
	return -2;
    }

    //send erase command.
    uint8_t buf[] = {0x60};
    adesto_xfer(buf, 1);

    //wait until the flash is not busy
    int32_t res = adesto_wait_not_busy(timeout);
    uint32_t stat = adesto_read_status_register();

    //check for errors
    if(stat & 0x20)
    {
	return -2;
    }
    if(res >= timeout)
    {
	return -1;
    }

    return (int32_t)res;
}

int32_t adesto_4k_erase(int timeout, uint32_t addr)
{
    //write enable
    if(adesto_write_enable() < 0)
    {
	return -2;
    }

    //send erase command
    uint8_t buf[] = {0x20, (addr >> 16) & 0xff, (addr >> 8) & 0xff, addr & 0xff};
    adesto_xfer(buf, 4);

    //wait until not busy
    int32_t res = adesto_wait_not_busy(timeout);
    uint32_t stat = adesto_read_status_register();

    //check for errors
    if(stat & 0x20)
    {
	return -2;
    }
    if(res >= timeout)
    {
	return -1;
    }

    return (int32_t)res;
}

int32_t adesto_read(uint32_t addr, uint8_t* dest, int len)
{
    if(adesto_wait_not_busy(1000) < 0)
    {
	return -1;
    }

    uint8_t buf[len + 6];
    buf[0] = 0x1b; buf[1] = (addr >> 16) & 0xff; buf[2] = (addr >> 8) & 0xff;
    buf[3] = addr & 0xff;
    adesto_xfer(buf, len + 6);

    memcpy(dest, buf + 6, sizeof(uint8_t)*len);
    return 0;
}

int32_t adesto_write(uint32_t addr, uint8_t* dat, int len)
{
    //wait up to 1000ms for timeout.
    if(adesto_wait_not_busy(1000) < 0)
    {
	return -1;
    }

    //write enable
    int32_t p;
    if((p = adesto_write_enable()) < 0)
    {
	return p;
    }

    //TODO? check bounds
    uint32_t end_addr;

    uint8_t buf[len + 4];
    buf[0] = 0x02; buf[1] = (addr >> 16) & 0xff; buf[2] = (addr >> 8) & 0xff;
    buf[3] = addr & 0xff;
    memcpy(buf + 4, dat, len);
    adesto_xfer(buf, len + 4);
    return 1;
}
