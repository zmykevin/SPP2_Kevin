#include <stdlib.h>
#include "board.h"

#if !(defined GIGE_H)
#define GIGE_H

//ethernet memory
//GIGE buffer space
#define RX_BUF_SPACE 0x3000
#define TX_BUF_SPACE 0x1000
extern __attribute__((__aligned__(16), __section__(".region_dma_nocache"))) uint8_t rxbuf[RX_BUF_SPACE];
extern __attribute__((__aligned__(16), __section__(".region_dma_nocache"))) uint8_t txbuf[TX_BUF_SPACE];
#define TX_FRAME_LEN 0x40
#define RX_FRAME_LEN 0x300
#define NUM_RX_FRAMES (RX_BUF_SPACE/RX_FRAME_LEN)
#define NUM_TX_FRAMES (TX_BUF_SPACE/TX_FRAME_LEN)

extern __attribute__((__aligned__(16), __section__(".region_dma_nocache"))) \
uint32_t rxframelist[NUM_RX_FRAMES << 1];
extern __attribute__((__aligned__(16), __section__(".region_dma_nocache"))) \
uint32_t txframelist[NUM_TX_FRAMES << 1];

//ethernet routines.  TODO: relocate to gige.c/.h
#define RXC_FUDGE_FACTOR 15
#define TXC_FUDGE_FACTOR 15
#define TXEN_FUDGE_FACTOR 7
#define TXD_FUDGE_FACTORS 0x1437
#define RXD_FUDGE_FACTORS 0x4444
#define PHY_ADDR 0b00001

uint16_t Read_PHY(uint8_t, uint8_t);
void Write_PHY(uint8_t, uint8_t, uint16_t);
void PHY_restart_auto_negotiation(int);
void PHY_auto_negotiate(void);
void construct_rx_descriptor_list(uint8_t*, uint32_t*,uint16_t, uint16_t);
void construct_tx_descriptor_list(uint8_t*, uint32_t*, uint16_t, uint16_t);
void dump_PHY_registers(int);

#endif

