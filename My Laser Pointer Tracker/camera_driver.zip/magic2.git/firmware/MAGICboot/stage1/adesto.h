#include <stdlib.h>
#include <string.h>
#include "board.h"

#if !(defined ADESTO_H)
#define ADESTO_H

#define CHIP_SELECT 0b1110
#define ADESTO_SECTOR_SIZE 0x10000
#define ADESTO_PAGE_SIZE 0x100
#define ADESTO_MAX_ADDR 0x3fffff
#define SPI_BUS_DIVIDER 0x04
#define DELAY_BETWEEN_TX 0x00

void adesto_xfer(uint8_t*, uint32_t);
uint32_t adesto_read_status_register(void);
uint32_t adesto_wait_not_busy(uint32_t);
int32_t adesto_write_enable(void);
int32_t adesto_read_status_protection_register(uint32_t);
int32_t adesto_unprotect_sector(uint32_t);
int32_t adesto_full_erase(int);
int32_t adesto_4k_erase(int, uint32_t);
int32_t adesto_read(uint32_t, uint8_t*, int);
int32_t adesto_write(uint32_t, uint8_t*, int);

#endif
