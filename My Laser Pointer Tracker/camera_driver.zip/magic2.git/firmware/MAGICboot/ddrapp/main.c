#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "unixdict.h"
#include "board.h"
#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)
#define READ_REGISTER(var,reg) __asm volatile("mov %[result], " TOSTRING(reg) "\n\t" : [result] "=r" (var))

volatile uint32_t timestamp = 0;

static void _Pit_Handler( void )
{
    uint32_t status;

    /* Read the PIT status register */
    status = PIT_GetStatus() & PIT_SR_PITS;
    if (status != 0) {
        /* 1 = The Periodic Interval timer has reached PIV since the last read of PIT_PIVR.
            Read the PIVR to acknowledge interrupt and get number of ticks
            Returns the number of occurrences of periodic intervals since the last read of PIT_PIVR. */
        timestamp += (PIT_GetPIVR() >> 20);
    }
}

int main( void )
{
    // Disable watchdog
    WDT_Disable(WDT);
    
    DBGU_ConsoleUseDBGU();
    printf("ddrapp main\r\n");
     
    printf( "Configure PIT \n\r" ) ;
    PMC->PMC_PCER0 = 1 << ID_PIT;

    // Initialize PIT to the desired period (1000ms)
    PIT_Init(1000, BOARD_MCK / 1000000);
    IRQ_ConfigureIT(ID_PIT, 0, _Pit_Handler);
    IRQ_EnableIT(ID_PIT);
    PIT_EnableIT();
    PIT_Enable();
    
    printf("PIT interrupt resides at %p\r\n", _Pit_Handler);
    
    uint32_t pc;
    READ_REGISTER(pc, pc);
    printf("pc = $%08x\r\n", pc);
    
    while(1)
    {
	if(timestamp > 250)
	{
	    printf("a");
	    timestamp = 0;
	}
    }
}
